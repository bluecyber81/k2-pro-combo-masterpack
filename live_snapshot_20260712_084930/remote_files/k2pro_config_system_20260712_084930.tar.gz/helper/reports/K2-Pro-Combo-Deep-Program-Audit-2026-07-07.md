# K2 Pro Combo deep program audit - 2026-07-07

## Scope

Live target: `192.168.178.74`

Checked:

- System identity, storage, memory and running services
- Klipper, Moonraker, Fluidd, Mainsail, go2rtc and helper daemons
- Moonraker API, update-manager state and frontend HTTP checks
- Klipper config/includes/macros and recent logs
- CFS/BOX live object state, CFS material databases and DB guard
- Spoolman API, spool/filament/vendor data and active CFS map
- Runtime junk, broken symlinks and helper audit tools
- External update state from official project release sources

Local raw audit folder:

`outputs/k2pro_deep_program_audit_20260707_213121`

All 13 audit collection commands returned `RC=0`.

## Live printer status

- Hostname: `K2Pro-Chris`
- Model: `F012`
- Board: `CR0CN200400C10`
- Firmware: `1.1.6.3`
- Kernel: `5.4.61`
- Uptime at audit: `1 day, 3:01`
- Root overlay: `26%` used
- UDISK: `2%` used
- Memory available: about `245 MB`
- Helper: `v5.2.21.57-live-audited-improved`

## Services and ports

Healthy and single-instance where expected:

- Klipper: running, Moonraker reports printer `ready`
- Moonraker: running on `7125`
- Fluidd: `4408`, HTTP 200
- Mainsail: `4409`, HTTP 200
- go2rtc: `1984`, stream API HTTP 200
- Spoolman CFS sync: one daemon process
- Camera watchdog: one daemon process
- Creality timelapse recover: one daemon process
- CFS DB guard: installed

Spoolman server itself is not running on the printer. The printer connects to:

`http://192.168.178.43:7912`

## Frontend update state

- Fluidd installed: `v1.37.2`
- Official Fluidd latest checked: `v1.37.2`
- Mainsail installed: `v2.18.2`
- Official Mainsail latest checked: `v2.18.2`

Decision:

- No Fluidd update needed.
- No Mainsail update needed.

## Spoolman state

Moonraker Spoolman:

- Connected: `true`
- Active spool: `1`
- Pending reports: none

Spoolman API on `192.168.178.43:7912`:

- Version: `0.23.1`
- DB type: `sqlite`
- Automatic backups: `true`
- Spools: `10`
- Filaments: `60`
- Vendors: `4`

Official Spoolman latest checked: `v0.24.0`

Decision:

- Spoolman has an update available: `0.23.1 -> 0.24.0`.
- This cannot be applied from the printer root session because Spoolman runs on the separate host `192.168.178.43`, not on `192.168.178.74`.
- Need SSH/Docker/host access to `192.168.178.43` before updating Spoolman.

Data quality:

- CFS map is enabled and valid: `T1A=1`, `T1B=2`, `T1C=3`, `T1D=4`.
- Spool 1-4 match the live CFS slots.
- One duplicate filament definition exists for `Creality / Hyper PLA White / PLA / FFFFFF`: filament IDs `1` and `60`.
- I did not merge this automatically because both are referenced by real spools with different comments/external IDs and changing them could lose provenance.

## Klipper and Moonraker

Moonraker API:

- `klippy_connected=true`
- `klippy_state=ready`
- `failed_components=[]`
- `warnings=[]`
- API version: `1.0.5`

Klipper:

- Moonraker reports Klipper software version `09faed31-dirty`.
- This is a Creality firmware/vendor tree, not a clean upstream Klipper checkout.

Update-manager:

- `busy=false`
- Klipper/Moonraker detected as zip/vendor trees with incomplete git release metadata.
- Moonraker update-manager therefore reports source validation messages and misleading remote/version data.

Decision:

- Do not update Klipper or Moonraker through the web UI/update-manager on this Creality printer.
- Official Klipper has newer upstream releases, but that does not mean they are compatible with Creality's K2 Pro firmware bundle.
- No Klipper/Moonraker core update or firmware flash was performed.

## CFS and material databases

Live CFS:

- BOX state: `connect`
- T1 state: `connect`
- T1 firmware: `1.4.2`
- Slots: T1A/T1B/T1C/T1D populated
- CFS material IDs: `101001,090001,000002,090002`

Health:

- `helper.sh --health-cfs`: `OK 24 / WARN 0 / FAIL 0`
- CFS protocol: `db_missing=0`, `db_ambiguous=1`
- CFS DB guard: no repair needed

Direct DB parse:

- `material_database.json`: JSON OK
- `material_box_info.json`: JSON OK
- `material_modify_info.json`: JSON OK
- `material_option.json`: JSON OK
- `remain_material_data.json`: JSON OK
- `tn_data.json`: JSON OK
- `usrMaterial/userMaterial.json`: JSON OK

Decision:

- No CFS database rewrite needed.
- The single ambiguity is T1C material ID `000002`, shared by Generic/Sovol PLA-Silk-like profiles. The live CFS protocol report explicitly says no repair is required.
- No raw CFS/BOX load, unload, extrude, retract, refresh or RS485 command was sent.

## Logs and known noise

Not current failures:

- Moonraker log contains old JSON-RPC/Traceback lines from earlier requests.
- go2rtc has old `broken pipe` entries, typical when a client disconnects from MJPEG.
- CFS/RS485 timeout messages are present at INFO level; helper health classifies the current level as acceptable and the CFS remains connected.

Still healthy:

- `helper.sh --health`: `OK 69 / WARN 1 / FAIL 0`
- `helper.sh --dependency-audit`: `OK 68 / WARN_OR_INFO 14 / FAIL 0`
- `helper.sh --deep-file-audit`: `OK 184 / INFO 8 / WARN 1 / FAIL 0`
- No broken symlinks in checked roots
- No helper `.pyc`, `__pycache__` or `.tmp-v57` junk

## Actions taken

- No risky live changes were applied in this pass.
- No core updates were installed.
- No firmware was flashed.
- No CFS movement/material command was sent.
- This report was created as the actionable output of the full live audit.

## Next possible action

Update Spoolman on host `192.168.178.43` from `0.23.1` to `0.24.0` after confirming host access and taking a Spoolman backup. The printer side is already ready for it.
