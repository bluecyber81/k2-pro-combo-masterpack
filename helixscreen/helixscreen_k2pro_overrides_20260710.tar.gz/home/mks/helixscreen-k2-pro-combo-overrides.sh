#!/bin/sh
set -eu
python3 - <<'PY'
import json
from pathlib import Path

SETTINGS = Path('/home/mks/helixscreen/config/settings.json')
K2_PRESET = Path('/home/mks/helixscreen/assets/config/presets/k2.json')

POLICY = (
    'K2 Pro Combo remote display: CFS/BOX is authoritative. '
    'Keep Klipper filament_switch_sensor visible but role=none in Helix to avoid false runout while CFS handles material state.'
)


def write_json_if_changed(path: Path, data, original: str) -> bool:
    rendered = json.dumps(data, indent=2, ensure_ascii=False) + '\n'
    if rendered != original:
        path.write_text(rendered)
        return True
    return False


def patch_display(root) -> bool:
    display = root.setdefault('display', {})
    changed = False
    # The Raspberry Pi panel is physically landscape. Creality K2 built-in display
    # presets can write a portrait rotate value that makes this remote display wrong.
    if display.pop('rotate', None) is not None:
        changed = True
    if display.get('rotation_probed') is not True:
        display['rotation_probed'] = True
        changed = True
    # Upstream Helix v0.99.88 recommends animations off for software-rotated panels;
    # keeping them off also makes the Pi screen feel more responsive.
    if display.get('animations_enabled') is not False:
        display['animations_enabled'] = False
        changed = True
    # Helix v0.99.88 accepts fixed timer steps. The previously configured
    # 900/3600 values were snapped on every start and produced warning logs.
    for key, value in {'dim_sec': 600, 'sleep_sec': 1800}.items():
        if display.get(key) != value:
            display[key] = value
            changed = True
    return changed


def patch_printer(printer) -> bool:
    if not isinstance(printer, dict):
        return False
    changed = False
    sensors_cfg = printer.setdefault('filament_sensors', {})
    if sensors_cfg.get('master_enabled') is not True:
        sensors_cfg['master_enabled'] = True
        changed = True
    sensors = sensors_cfg.setdefault('sensors', [])
    target = None
    for sensor in sensors:
        if isinstance(sensor, dict) and sensor.get('klipper_name') == 'filament_switch_sensor filament_sensor':
            target = sensor
            break
    if target is None:
        target = {
            'enabled': True,
            'klipper_name': 'filament_switch_sensor filament_sensor',
            'role': 'none',
            'type': 'switch',
        }
        sensors.append(target)
        changed = True
    desired = {
        'enabled': True,
        'klipper_name': 'filament_switch_sensor filament_sensor',
        'role': 'none',
        'type': 'switch',
    }
    for key, value in desired.items():
        if target.get(key) != value:
            target[key] = value
            changed = True
    notes = printer.setdefault('notes', {})
    if notes.get('filament_sensor_policy') != POLICY:
        notes['filament_sensor_policy'] = POLICY
        changed = True
    return changed


def patch_settings() -> bool:
    if not SETTINGS.exists():
        return False
    original = SETTINGS.read_text()
    data = json.loads(original)
    changed = patch_display(data)
    printers = data.get('printers')
    if isinstance(printers, dict):
        for printer in printers.values():
            changed = patch_printer(printer) or changed
    return write_json_if_changed(SETTINGS, data, original) if changed else False


def patch_preset() -> bool:
    if not K2_PRESET.exists():
        return False
    original = K2_PRESET.read_text()
    data = json.loads(original)
    changed = patch_display(data)
    changed = patch_printer(data.setdefault('printer', {})) or changed
    return write_json_if_changed(K2_PRESET, data, original) if changed else False

changed_settings = patch_settings()
changed_preset = patch_preset()
print(f'k2_pro_combo_overrides settings_changed={changed_settings} preset_changed={changed_preset}')
PY
chown mks:mks /home/mks/helixscreen/config/settings.json 2>/dev/null || true
chown mks:mks /home/mks/helixscreen/assets/config/presets/k2.json 2>/dev/null || true
