#!/bin/sh
set -eu
exec /home/mks/helixscreen-k2-pro-combo-overrides.sh
